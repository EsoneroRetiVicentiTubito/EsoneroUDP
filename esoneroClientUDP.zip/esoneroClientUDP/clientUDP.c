/*
 * clientUDP.c
 *
 *  Created on: 10 dic 2021
 *      Author: mtubi
 */

#include "clientUDP.h"

void ErrorHandler(char *errorMessage) {
	printf(errorMessage + '\n');
}

void ClearWinSock() {
#if defined WIN32
	WSACleanup();
#endif
}

int clientUDP() {
#if defined WIN32
	WSADATA wsaData;
	int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0) {
		printf("error at WSASturtup\n");
		return EXIT_FAILURE;
	}
#endif
	struct sockaddr_in srvAddr;
	struct sockaddr_in srvAddrReceve;
	struct in_addr *mina = NULL;
	struct hostent *host = NULL;
	char *srvNameReceve = NULL;
	char srvName[BUFFERSIZE] = { };
	int port = 0;
	int error = 0;
	int correctInput = 0;
	char buffer[BUFFERSIZE] = { };
	char input[BUFFERSIZE] = { };
	int addrLen = 0;
	int sock = 0;
	char answer;
		do {
			puts("Type 'y' to insert name address and port or 'n' to connect in localhost \n");
			scanf("%c", &answer);
			inputClear();
		} while (answer != 'y' && answer != 'n');
		if(answer == 'y'){
	do {
		memset(&srvAddr, 0, sizeof(srvAddr));
		memset(input, 0, strlen(input));
		memset(srvName, 0, strlen(srvName));
		error = 0;
		puts("Type server Name:port number\n");
		scanf("%255s", input);
		inputClear();
		port = returnPortAndSrvName(input, srvName);
		if (port != -1) {
			host = gethostbyname(srvName);
			if (host == NULL) {
				error = 1;
				puts("ATTENTION!! Server name is wrong\n");
			}
			else{
				mina = (struct in_addr*) host->h_addr_list[0];
				srvAddr.sin_addr = *mina;
			}
		} else {
			error = 1;
			puts("ATTENTION!! Port Number is wrong\n");
		}
	} while (error == 1);
		}
		else{
			memset(&srvAddr, 0, sizeof(srvAddr));
			port = PORT;
			srvAddr.sin_addr.s_addr = inet_addr(LOCALHOST);
		}
	srvAddr.sin_family = AF_INET;
	srvAddr.sin_port = htons(port);
	if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
		puts("socket() failed \n");
		closesocket(sock);
		ClearWinSock();
		return -1;
	}
	if (error == 0) {
		do {
			do {
				memset(buffer, 0, strlen(buffer));
				correctInput = 0;
				puts("Enter the operation to run on the server \n");
				fflush(stdin);
				gets(buffer);
				correctInput = stringVerify(buffer);
			} while (correctInput != 1);
			if (sendto(sock, buffer, strlen(buffer), 0,
					(struct sockaddr*) &srvAddr, sizeof(srvAddr)) < 0) {
				puts("sendto() failed \n");
				closesocket(sock);
				ClearWinSock();
				return -1;
			} else {
				if (buffer[0] != '=') {
					addrLen = sizeof(srvAddrReceve);
					if (recvfrom(sock, buffer, BUFFERSIZE, 0,(struct sockaddr*) &srvAddrReceve, &addrLen) < 0) {
						puts("recv() failed \n");
						closesocket(sock);
						ClearWinSock();
						return -1;
					} else {
						if (srvAddr.sin_addr.S_un.S_addr
								== srvAddrReceve.sin_addr.S_un.S_addr) {
							host = gethostbyaddr(
									(char*) &srvAddrReceve.sin_addr, 4,
									AF_INET);
							srvNameReceve = host->h_name;
							printf("result recived from server %s, ip %s: %s \n",srvNameReceve,inet_ntoa(srvAddrReceve.sin_addr), buffer);
						} else {
							puts("Error: received a packet from unknown source.\n");
						}
					}
				}
				else{
					puts("closing in progress \n");
				}
			}
		} while (buffer[0] != '=' && error == 0);
	}
	closesocket(sock);
	ClearWinSock();
	return 1;
}

int returnPortAndSrvName(char input[], char name[]) {
	char portNumberS[5] = { };
	int portNumber = 0;
	int i;
	int firstPart = 0;
	int error = 0;
	int j;
	for (i = 0; i < strlen(input) && firstPart == 0; i++) {
		if (input[i] != ':') {
			name[i] = input[i];
		} else {
			firstPart = 1;
		}
	}
	if (firstPart == 1) {
		for (j = 0; i < strlen(input) && error == 0; i++) {
			if (isdigit(input[i])) {
				portNumberS[j] = input[i];
			} else {
				error = 1;
				puts("ATTENTION!! Invalid port number\n");
				return -1;
			}
			j++;
		}
	} else {
		puts("ATTENTION!!Invalid input\n");
		return -1;
	}
	portNumber = atoi(portNumberS);
	if (portNumber != PORT) {
		return -1;
		puts("ATTENTION!! Port number is wrong\n");
	} else {
		return portNumber;
	}
}
