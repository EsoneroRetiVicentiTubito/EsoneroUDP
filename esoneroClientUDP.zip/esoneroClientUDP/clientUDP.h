/*
 * clientUDP.h
 *
 *  Created on: 10 dic 2021
 *      Author: mtubi
 */

#ifndef CLIENTUDP_H_
#define CLIENTUDP_H_


#include "applicationProtocol.h"
#include "verify.h"
#include <string.h> /* for memset() */
#include <ctype.h>


void ErrorHandler(char *errorMessage);
void ClearWinSock();
int clientUDP();
int returnPortAndSrvName(char input[], char name[]);

#endif /* CLIENTUDP_H_ */
