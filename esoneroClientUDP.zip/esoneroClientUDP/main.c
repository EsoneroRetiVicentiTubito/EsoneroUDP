/*
 * main.c
 *
 *  Created on: 10 dic 2021
 *      Author: mtubi
 */

#include "clientUDP.h"

int main(){
	clientUDP();
	system("pause");
	return 0;
}
