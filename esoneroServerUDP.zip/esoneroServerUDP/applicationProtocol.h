/*
 * applicatioProtocol.h
 *
 *  Created on: 12 dic 2021
 *      Author: mtubi
 */

#ifndef APPLICATIONPROTOCOL_H_
#define APPLICATIONPROTOCOL_H_


#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif

#define PORT 48000
#define BUFFERSIZE 500
#define LOCALHOST "127.0.0.1"
#endif /* APPLICATIONPROTOCOL_H_ */
