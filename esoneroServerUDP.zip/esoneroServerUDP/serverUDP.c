/*
 * serverUDP.c
 *
 *  Created on: 10 dic 2021
 *      Author: mtubi
 */

#include "serverUDP.h"

void ErrorHandler(char *errorMessage) {
	printf(errorMessage);
}

void ClearWinSock() {
#if defined WIN32
	WSACleanup();
#endif
}

int serverUDP() {
#if defined WIN32
	WSADATA wsaData;
	int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0) {
		printf("error at WSASturtup\n");
		return EXIT_FAILURE;
	}
#endif

	int sock;
	struct sockaddr_in servAddr;
	struct sockaddr_in clntAddr;
	int cliAddrLen;
	struct hostent *host;
	char *nameClnt;

	char buffer[BUFFERSIZE] = { };

	if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
		ErrorHandler("socket() failed");
		ClearWinSock();
		return -1;
	}
	memset(&servAddr, 0, sizeof(servAddr));
	servAddr.sin_family = AF_INET;
	servAddr.sin_port = htons(PORT);
	servAddr.sin_addr.s_addr = inet_addr(LOCALHOST);

	if ((bind(sock, (struct sockaddr*) &servAddr, sizeof(servAddr))) < 0) {
		ErrorHandler("bind() failed");
		ClearWinSock();
		return -1;
	}
	printf("Waiting for a client to connect...\n");
	while (1) {
		memset(buffer, 0, sizeof(buffer));
		memset(&clntAddr, 0, sizeof(clntAddr));
		nameClnt = NULL;
		cliAddrLen = sizeof(clntAddr);
		if (recvfrom(sock, buffer, BUFFERSIZE, 0, (struct sockaddr*) &clntAddr,
				&cliAddrLen) < 0) {
			puts("recv() failed \n");
		} else {
			host = gethostbyaddr((char*) &clntAddr.sin_addr, 4, AF_INET);
			nameClnt = host->h_name;
			if (buffer[0] == '=') {
				printf("disconnection from client %s, ip %s\n",nameClnt, inet_ntoa(clntAddr.sin_addr));
			} else {
				printf("operation request '%s' from client %s, ip %s \n",
						buffer, nameClnt, inet_ntoa(clntAddr.sin_addr));
				stringCalculator(buffer);
				if (sendto(sock, buffer, strlen(buffer), 0,
						(struct sockaddr*) &clntAddr, sizeof(clntAddr)) < 0) {
					puts("sendto() failed");
				}
			}
		}
	}

	return 1;
}

