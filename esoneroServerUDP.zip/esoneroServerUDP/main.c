/*
 * main.c
 *
 *  Created on: 10 dic 2021
 *      Author: mtubi
 */
#include "serverUDP.h"

int main(){
	serverUDP();
	system("pause");
	return 0;
}
