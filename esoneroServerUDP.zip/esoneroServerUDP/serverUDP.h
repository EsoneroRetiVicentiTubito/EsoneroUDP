/*
 * serverUDP.h
 *
 *  Created on: 10 dic 2021
 *      Author: mtubi
 */

#ifndef SERVERUDP_H_
#define SERVERUDP_H_

#include "applicationProtocol.h"
#include <stdio.h>
#include <string.h> /* for memset() */
#include "maths.h"



void ErrorHandler(char *errorMessage);
void ClearWinSock();
int serverUDP();

#endif /* SERVERUDP_H_ */
